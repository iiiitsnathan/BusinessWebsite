# Route9 Printing Website

## Completed
- [x] Set up Next.js project with shadcn
- [x] Create dark, moody theme with red accents
- [x] Build navigation component
- [x] Create homepage with hero, services, about, process, contact sections
- [x] Create services page with detailed pricing
- [x] Build blog page with post listings
- [x] Create FAQ page with easter egg internship question
- [x] Add CV page for internship link
- [x] Create blog post template
- [x] Add Nathan's real CV information
- [x] Update services: remove E-6, B&W push/pull same price
- [x] Update scanning: 4000 DPI max, standard FREE, high-res $18
- [x] Only 35mm and 120 formats, mounted slides available
- [x] Update contact: nma@bbns.org, drop-off by email arrangement
- [x] Change B&W pricing to $10 (cheaper than C-41 at $12)
- [x] Replace contact form with direct email and phone
- [x] Rebrand to "Route9 Printing"

## Optional Enhancements
- [ ] Add actual photos from Nathan's portfolio
- [ ] Add more blog post content
- [ ] Deploy the website
- [ ] Add customer testimonials
